package Questao6;
/* Elabore um método que retorne as letras invertidas das palavras de uma frase recebida
por parâmetro, preservando a ordem das palavras na frase. Por exemplo “a maçã está
podre”, deve ter como saída: “a ãçam átse erdop”. As operações básicas de uma pilha,
push e pop, devem ser usadas
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Entrada da Pilha
        System.out.println("Entre com uma string: ");
        String s = scanner.nextLine();
        Pilha pilha = new Pilha(s.length());
        String palavra = new String();
        char c;
        int i = 0;
        while (i < s.length()) {
            c = s.charAt(i);
            pilha.push(c);
            i++;
        }

        ArrayList<String> aux = new ArrayList<String>();

        //Taca no array palavra invertida mantendo posição
        while (!pilha.vazia()) {
            c = pilha.pop();
            if (c == ' '){
                aux.add(palavra);
                palavra = "";
            }else if (pilha.getTopo()==-1){
                palavra = palavra+c;
                aux.add(palavra);
            }else{
                palavra += c;
            }
        }


        for (i = aux.size()-1; i >= 0;i--){
            System.out.print(aux.get(i)+" ");
        }



    }
}
