package Questao1;
/*Escreva uma função para determinar se uma cadeia de caracteres (string) é da forma: x
C y onde x e y são cadeias de caracteres compostas por letras ‘A’ e/ou ‘B’, e y é o inverso
de x. Isto é, se x = “ABABBA”, y deve equivaler a “ABBABA”. Em cada ponto, você só
poderá ler o próximo caractere da cadeia.
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o tamanho da cadeia:");
        int n = scanner.nextInt();
        Pilha cadeia = new Pilha(n);
        cadeia.lerString();

        testaPilha(cadeia);

    }

    //Questão 1

    public static boolean testaPilha(Pilha x){
        int divisao = x.getPosicaoC();
        if (divisao == '\0'){
            System.out.println("Não houve C");
            return false;
        }else if (divisao == -1){
            System.out.println("Não batem(X vazio)");
            return false;
        }else if(divisao == x.getN()-1){
            System.out.println("Não batem(Yvazio)");
            return false;
        }else {
            int m = x.getN() - divisao - 1;
            int n = x.getN() - m - 1;
            char temp[] = new char[n];
            char temp2[] = new char[m];

            //Trabalho em cima de X
            int i = n - 1;

            do {
                temp[i] = x.tirar();
                i--;
                if (i == -1) {
                    break;
                }
            } while (1 == 1);

            //x.tirar();

            //Trabalho em y
            int j = m - 1;

            do {
                temp2[j] = x.tirar();
                j--;
                if (j == -1) {
                    break;
                }
            } while (1 == 1);

            //Compara de fato
            i = 0;
            j = m - 1;
            if (n != m) {
                System.out.println("as cadeias nao tem nem o mesmo tamanho");
                return false;
            } else {
                do {
                    if (temp[i] != temp2[j]) {
                        System.out.println("Não bateu");
                        return false;
                    }
                    i++;
                    j--;
                } while (i < n);
                System.out.println("X equivale a a Y. ");
                return true;
            }
        }
    }
}