package Questao1;

import java.util.Scanner;

public class Pilha {
    Scanner scanner = new Scanner(System.in);

    private int n=0;
    private char vetor[];
    private int topo;
    private int posicaoC = '\0';

    public Pilha() {
        n = 10;
        vetor = new char[n];
        topo = -1;
    }

    public Pilha(int tamanho) {
        n = tamanho;
        vetor = new char[tamanho];
        topo = -1;
    }

    public boolean vazia()
    {
        return topo == -1 ? true : false;
    }

    public boolean cheia()
    {
        return topo == n - 1 ? true : false;
    }

    public char tirar() {
        char c = '\0';

        if (!this.vazia()) {
            c = vetor[topo];

            //Decrementando o topo, o elemento é "removido"
            topo--;
        }
        else{
            //Impressão para fins didáticos
            System.out.println("Pilha vazia: pop não funcionou.");
        }

        return c;
    }

    public boolean botar(char elemento) {
        if (!this.cheia()) {
            vetor[++topo] = elemento;
            return true;
        }
        else {
            //Impressão para fins didáticos
            System.out.println("Pilha cheia: push não funcionou.\n");
            return false;
        }
    }

    public char retornaTopo() {
        char elemento = '\0';

        if(!this.vazia()) {
            elemento = vetor[topo];
        }
        else {
            System.out.println("Pilha vazia.");
        }

        return elemento;
    }

    public void leChar(){
      char ch = '\0';
      ch = scanner.next().charAt(0);
      if (ch != 'A' && ch != 'B' && ch != 'C'){
          System.out.println("Só A,B e C por favor");
          leChar();
      }else if (ch == 'C'){
          if (posicaoC != '\0'){
              System.out.println("Já tem um C nessa cadeia");
              leChar();
          }else{
              posicaoC = getTopo()+1;
          }
      }else {
          botar(ch);
      }
    }

    public void lerString(){
        int i = 0;
        System.out.println("Digite os caracteres:");
        while (i<this.getN()){
            this.leChar();
            i++;
        }
    }

    public int getN() {
        return n;
    }
    public char[] getVetor() {
        return vetor;
    }
    public int getTopo() {
        return topo;
    }
    public int getPosicaoC(){
        return posicaoC;
    }

}