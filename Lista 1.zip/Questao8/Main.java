package Questao8;
/*Dada uma sequência de 1 a N armazenada em um array, são formadas todas as
subsequências (subarrays) possíveis a partir da sequência original. Para todas essas
subsequências geradas, encontre a quantidade de pares únicos (a, b), em que ‘a’ é
diferente de ‘b’ e ‘a’ é máximo (maior número) e ‘b’ é o segundo máximo da subsequência.
*/
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o 'n' de 1 a n");
        int n = scanner.nextInt();
        int vetor[] = new int[n];
        for (int i = 1; i <= n;i++){
            vetor[i-1]=i;
        }
        for (int i = 0; i < n;i++){
            System.out.println(vetor[i]);
        }
        for (int i = n-1; i > 0;i--){
            System.out.printf("(%d,%d)",vetor[i],vetor[i-1]);
        }
    }
}
