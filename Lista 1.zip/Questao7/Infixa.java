package Questao7;

import java.util.Scanner;

public class Infixa {

        private Integer resposta;
        private PilhaGenerica<Integer> pilha;
        private PilhaGenerica<Character> inicio;
        private PilhaGenerica<Character> operacao;
        private String x;
        private Scanner scan;

        public Infixa(int tamanhoPilha) {
            pilha = new PilhaGenerica<>(tamanhoPilha);
            inicio = new PilhaGenerica<>(tamanhoPilha);
            operacao = new PilhaGenerica<>(tamanhoPilha);
            x = "";
            scan = new Scanner(System.in);
        }

        private boolean qualOp(char simbolo){
            if (simbolo == '*' || simbolo == '+' ||
                    simbolo == '-' || simbolo == '/')
                return true;

            return false;
        }

        private boolean operar()
        {
            Integer operando1 = 0, operando2 = 0;

            // Desempilha dois operandos
            operando1 = pilha.pop();
            operando2 = pilha.pop();
            char operador = operacao.pop();


            if (operando1 == null || operando2 == null) return false;

            switch (operador) {
                case '*':
                    pilha.push(operando1 * operando2);  break;
                case '+':
                    pilha.push(operando1 + operando2); break;
                case '/':
                    pilha.push(operando2 / operando1);  break;
                case '-':
                    pilha.push(operando2 - operando1);  break;
                default:
                    return false;
            }
            return true;
        }

    public void calcular(String x){
        x = x;

        for(int i = 0; i < x.length(); i++) {
            if(x.charAt(i) == '(')
                inicio.push('(');

            if(qualOp(x.charAt(i)))
                operacao.push(x.charAt(i));

            if(x.charAt(i) == ')')
                operar();

            if ((x.charAt(i) >= '0')
                    && (x.charAt(i) <= '9')) {
                pilha.push(Character.getNumericValue( x.charAt(i) ));
            }

        }

        System.out.println("Resposta = " + pilha.pop());

    }







}
