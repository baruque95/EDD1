package Questao7;
//Muito texto nesse enunciado
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Entre com expressao infixada: ");
        String x = scanner.nextLine();

        Infixa in = new Infixa(x.length());
        in.calcular(x);
    }
}
