package Questao4;

import java.util.Scanner;
/*Utilizando as operações de manipulação de pilhas vistas em aula, assim como o código
de PilhaGenerica visto, use uma pilha auxiliar e uma variável do tipo T, para desenvolver
um procedimento que remova um dado objeto do tipo T de uma posição qualquer de uma
pilha. Para saber se dois objetos do tipo T são iguais, você deve usar o método equals (ou
compareTo). Note que você não pode acessar diretamente a estrutura interna da pilha
(atributos), devendo usar apenas as operações (métodos) de manipulação.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Entrada da Pilha
        System.out.println("Entre com uma string: ");
        String s1 = scanner.nextLine();
        PilhaGenerica pilha = new PilhaGenerica(s1.length());
        Object c = new Object();
        int i = 0;
        while (i < s1.length()) {
            c = s1.charAt(i);
            pilha.push(c);
            i++;
        }

        //Pega o objeto a ser removido
        System.out.println("Digite o objeto que sera removido: ");
        Object removido = scanner.next().charAt(0);

        //Cria a auxiliar;
        PilhaGenerica pilhaAux = new PilhaGenerica(s1.length());

        //procura
        while (!pilha.vazia()) {
            c = pilha.pop();
            if (PilhaGenerica.equals(c,removido)){
                break;
            }
            pilhaAux.push(c);
        }


        while (!pilhaAux.vazia()) {
            c = pilhaAux.pop();
            pilha.push(c);
        }
        System.out.println("Resultado:");
        while (!pilha.vazia()) {
            c = pilha.pop();
            System.out.println(c);
        }

    }
}
