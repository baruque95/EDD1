package Questao2;

import java.util.ArrayList;
import java.util.Scanner;

public class Pilha {
    Scanner scanner = new Scanner(System.in);

    private ArrayList<Character> vetor;
    private int topo;
    private int posicaoC = '\0';
    private int numeroC = 0;
    private int numeroD = 0;
    private int erros = 0;
    private int numeroCadeias = 0;

    public Pilha() {
        vetor = new ArrayList<Character>();
        topo = -1;
    }

    public boolean vazia()
    {
        return topo == -1 ? true : false;
    }


    public char tirar() {
        char c = '\0';

        if (!this.vazia()) {
            c = vetor.get(topo);

            //Decrementando o topo, o elemento é "removido"
            topo--;
        }
        else{
            //Impressão para fins didáticos
            System.out.println("Pilha vazia: pop não funcionou.");
        }

        return c;
    }

    public boolean botar(char elemento) {
            vetor.add(elemento);
            topo++;
            return true;
    }

    public char retornaTopo() {
        char elemento = '\0';

        if(!this.vazia()) {
            elemento = vetor.get(topo);
        }
        else {
            System.out.println("Pilha vazia.");
        }

        return elemento;
    }

    //Entrada de dados na pilha
    public char leChar(){
        char ch = '\0';
        ch = scanner.next().charAt(0);
        if (ch == '1'){
            return ch;
        }
        if (ch == 'A' || ch == 'B' || ch == 'C'){
            if (ch == 'C') {
                if (posicaoC != '\0') {
                    erros++;
                }
            }
            botar(ch);
            return ch;
        }else if (ch=='D'){
            return ch;
        }else{
            System.out.println("Somente A,B,C,D e 1");
            leChar();
        }
        return 'a';
    }

    //conclui o programa e chama le char
    public void lerString(){
        while (1==1){
            char ch = this.leChar();
            if (ch == 'C'){
                posicaoC = this.getVetor().size();
            }
            if(ch == 'D'){
                numeroCadeias++;
                numeroD++;
                testaPilha(this);
                posicaoC='\0';
            }
            if (ch == '1') {
                if (numeroCadeias==0){
                    erros++;
                }
                if (numeroD==0){
                    erros++;
                }
                if(erros>0){
                    System.out.println("Nao ta no formato certo");
                }
                if (erros==0){
                    System.out.println("Estao no formato certo.");
                }
                System.out.println("FIM");
                break;
            }
        }
    }

    public static void testaPilha(Pilha x){
        int divisao = x.getPosicaoC();
        if (divisao == '\0'){
            x.erros++;
        }else if (divisao == -1){
            x.erros++;
        }else if(divisao == x.getVetor().size()-1){
            x.erros++;
        }else {
            int m = x.getVetor().size() - divisao;
            //System.out.println(m);
            int n = x.getVetor().size() - m - 1;
            //System.out.println(n);
            char temp[] = new char[n];
            char temp2[] = new char[m];

            //Trabalho em cima de X
            int i = n - 1;

            if (i > 0) {
                do {
                    temp[i] = x.tirar();
                    i--;
                    if (i == -1) {
                        break;
                    }
                } while (1 == 1);
            }
            x.tirar();

            //Trabalho em y
            int j = m - 1;

            if (j > 0) {
                do {
                    temp2[j] = x.tirar();
                    j--;
                    if (j == -1) {
                        break;
                    }
                } while (1 == 1);
            }

            //Compara de fato
            i = 0;
            j = m - 1;
            if (n != m) {
                x.erros++;
            } else {
                do {
                    if (temp[i] != temp2[j]) {
                        x.erros++;
                    }
                    i++;
                    j--;
                } while (i < n);
            }
        }
    }

    public ArrayList<Character> getVetor() {
        return vetor;
    }
    public int getTopo() {
        return topo;
    }
    public int getPosicaoC(){
        return posicaoC;
    }

}