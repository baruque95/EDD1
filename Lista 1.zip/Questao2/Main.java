package Questao2;
/*Escreva uma função para determinar se uma cadeia de caracteres (string) é da forma: a
D b D c D ... D z onde cada cadeia de caracteres, a, b, ..., z, é da forma do exercício
descrito acima. Portanto, uma cadeia de caracteres estará no formato correto se consistir
em qualquer número de cadeias deste tipo ( x C y ), separadas pelo caractere ‘D’. Em cada
ponto, você só poderá ler o próximo caractere da cadeia (é mandatório o uso de pilha).
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pilha cadeia = new Pilha();
        System.out.println("Digite os caracteres (1 para parar):");

        cadeia.lerString();

    }
}
