package Questao5;

import java.util.Scanner;
/*Escreva um programa que leia uma sequência de caracteres e determine se os
parênteses, colchetes e chaves estão balanceados. Se a sequência não possuir esses
caracteres ele deve ser considerado balanceado. Exemplo:
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Entrada da Pilha
        System.out.println("Entre com uma string: ");
        String s = scanner.nextLine();
        Pilha pilha = new Pilha(s.length());
        int erros = 0;
        boolean abreP=false;
        boolean abreCo=false;
        boolean abreCh=false;
        char c;
        int i = 0;
        while (i < s.length()) {
            c = s.charAt(i);
            pilha.push(c);
            if (c == '('){
                if (abreP){
                    erros++;
                }
                abreP = true;
            }
            if (c == ')'){
                if (!abreP){
                    erros++;
                }
                abreP = false;
            }
            if (c == '['){
                if (abreP){
                    erros++;
                }
                if (abreCo){
                    erros++;
                }
                abreCo = true;
            }
            if (c == ']'){
                if (!abreCo){
                    erros++;
                }
                abreCo = false;
            }
            if (c == '{'){
                if (abreCo) {
                    erros++;
                }
                if (abreCh) {
                    erros++;
                }
                abreCh = true;
            }
            if (c == '}'){
                if (!abreCh){
                    erros++;
                }
                abreCh = false;
            }
            i++;
        }
        //sobrou um aberto
        if(abreP || abreCo || abreCh){
            erros++;
        }

        if (erros==0){
            System.out.println("Balanceado.");
        }else{
            System.out.println("Nao balanceado");
        }

    }
}
