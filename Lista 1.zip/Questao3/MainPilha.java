package Questao3;
/*) Desenvolva um m�todo para manter duas pilhas dentro de um �nico vetor (array) de
modo que nenhuma das pilhas incorra em estouro at� que toda a mem�ria seja usada, e
toda uma pilha nunca seja deslocada para outro local dentro do vetor.
 */
import java.util.Scanner;

public class MainPilha {
	public static void main(String args[]){
		Scanner scanner = new Scanner(System.in);

		System.out.println("Digite a memoria a ser alocada:");
		int n = scanner.nextInt();
		char teste[] = new char[n];
		System.out.println("Entre com outra string: ");
		String s1 = scanner.next();
		System.out.println("Entre com outra string: ");
		String s2 = scanner.next();

		Pilha pilha1 = new Pilha(s1.length());
		Pilha pilha2 = new Pilha(s2.length());

		char c;
		
		int i = 0;
		
		while ( i < s1.length() ) {
			c = s1.charAt(i);
			pilha1.push(c);
			teste[i] = c;
			i++;
		}

		int j = 0;
		while (j < s2.length()) {
			c = s2.charAt(j);
			pilha2.push(c);
			teste[i+j]=c;
			j++;
		}
		
		System.out.println("saida das pilhas: ");
		
		for (i = 0; i<n;i++){
			System.out.println(teste[i]);
		}

		
		System.out.print("\n");
		
		scanner.close();
	}
}
